import request, { gql } from "graphql-request";

const MASTER_URL =
  "https://api-us-west-2.hygraph.com/v2/clovwhwrz4eud01uqfl739ivx/master";

export const getVans = async () => {
  const query = gql`
    query Vans {
      vanTypes {
        id
        name
        image {
          width
          url
          height
        }
      }
    }
  `;
  const result = await request(MASTER_URL, query);
  return result;
};

export const getSteps = async (props) => {
  console.log(props);
  const stepQuery = gql`
    query Steps {
      vanTypes(where: { id: "${props}" }) {
        name
        stepCategories {
          ... on StepCategory {
            id
            name
          }
        }
      }
    }
  `;
  const stepResult = await request(MASTER_URL, stepQuery);
  return stepResult;
};

export const getOptions = async (props) => {
  const optionQuery = gql`
    query optionQuery {
      options(where: { stepCategory: { id: "${props}" } }) {
        name
    id
    toolTip
    default
    stepCategory {
      name
    }
    optionGroups {
      name
      id
    }
    image {
      url
      width
      height
    }
      }
    }
  `;
  const stepResult = await request(MASTER_URL, optionQuery);
  return stepResult;
};
