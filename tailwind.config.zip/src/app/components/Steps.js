import { useState } from "react";
import { getOptions } from "../../../graphql";
import Box from "@mui/material/Box";
import Stepper from "@mui/material/Stepper";
import Step from "@mui/material/Step";
import StepLabel from "@mui/material/StepLabel";
import OptionCard from "./OptionCard";
import OverlayImages from "./OverlayImages";

const VanSteps = ({ steps, selectedVan }) => {
  const [options, setOptions] = useState([]);

  const [currentGroupIndex, setCurrentGroupIndex] = useState(0);

  // Function to show next group
  const showNextGroup = () => {
    setCurrentGroupIndex((prevIndex) => prevIndex + 1);
  };

  // Function to show previous group
  const showPreviousGroup = () => {
    setCurrentGroupIndex((prevIndex) =>
      prevIndex > 0 ? prevIndex - 1 : prevIndex
    );
  };
  const [floorOption, setFloorOption] = useState([]);
  const [wiringHarness, setWiringHarness] = useState([]);
  const [powerSystem, setPowerSystem] = useState([]);
  const [ceilingPanel, setCeilingPanel] = useState([]);
  const [ceilingLighting, setCeilingLighting] = useState([]);
  const [ventalation, setVentalation] = useState([]);
  const [walls, setWalls] = useState([]);

  const [floorOptionImage, setFloorOptionImage] = useState("");
  const [wiringHarnessImage, setWiringHarnessImage] = useState("");
  const [powerSystemImage, setPowerSystemImage] = useState("");
  const [ceilingPanelImage, setCeilingPanelImage] = useState("");
  const [ceilingLightingImage, setCeilingLightingImage] = useState("");
  const [ventalationImage, setVentalationImage] = useState("");
  const [wallsImage, setWallsImage] = useState("");

  const vanOptions = async (props) => {
    const result = await getOptions(props);
    setOptions(result?.options);
  };

  const handleSelectItem = (item) => {
    //  setFloorOption(item.image.url);
    let optGroup = item.optionGroups[0].name;
    switch (optGroup) {
      case "Floor Color":
        setFloorOption(item);
        setFloorOptionImage(item.image.url);
        break;
      case "Wiring Harness":
        setWiringHarness(item);
        setWiringHarnessImage(item.image.url);
        break;
      case "48v Power System":
        setPowerSystem(item);
        setPowerSystemImage(item.image.url);
        break;
      case "Ceiling Panel":
        setCeilingPanel(item);
        setCeilingPanelImage(item.image.url);
        break;
      case "Lighting":
        item.image ? setCeilingLighting(item) : setCeilingLighting("");
        item.image
          ? setCeilingLightingImage(item.image.url)
          : setCeilingLightingImage([]);

        break;
      case "Ventalation":
        item.image ? setVentalation(item) : setVentalation("");
        item.image
          ? setVentalationImage(item.image.url)
          : setVentalationImage([]);
        break;
      case "Wall Panels":
        item.image ? setWalls(item) : setWalls("");
        break;
    }
  };
  console.log(floorOption);
  return (
    <>
      <Box className="top-50 bottom-steps" sx={{ width: "100%" }}>
        <Stepper activeStep={1} alternativeLabel>
          {steps.map((item) => (
            <Step
              onClick={(e) => {
                vanOptions(item.id);
              }}
              key={item.id}
            >
              <StepLabel>{item.name}</StepLabel>
            </Step>
          ))}
        </Stepper>
      </Box>
      <div className="flex top-50 relative">
        {steps.map((item) => (
          <button
            onClick={(e) => {
              vanOptions(item.id);
              setCurrentGroupIndex(0);
            }}
            className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 border border-blue-700 rounded"
            key={item.id}
          >
            {item.name}
          </button>
        ))}
      </div>
      <OptionCard
        options={options}
        onSelectItem={handleSelectItem}
        currentGroupIndex={currentGroupIndex}
        showNextGroup={showNextGroup}
        showPreviousGroup={showPreviousGroup}
        floorOption={floorOption}
      />
      <OverlayImages vanimage={floorOptionImage} />
      <OverlayImages vanimage={wiringHarnessImage} />
      <OverlayImages vanimage={powerSystemImage} />
      <OverlayImages vanimage={ceilingPanelImage} />
      <OverlayImages vanimage={ceilingLightingImage} />
      <OverlayImages vanimage={ventalationImage} />
    </>
  );
};

export default VanSteps;
