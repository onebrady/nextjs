import Image from "next/image";
import React from "react";

const OverlayImages = ({ vanimage }) => {
  if (vanimage !== "") {
    return (
      <>
        <Image
          className="main-bg"
          src={vanimage}
          width={1920}
          height={1080}
          alt=""
        />
      </>
    );
  }
  return "";
};

export default OverlayImages;
