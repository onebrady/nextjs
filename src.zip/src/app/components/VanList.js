"use client";
import { useState } from "react";
import Steps from "./Steps";
import { getSteps } from "../../../graphql";
import OverlayImages from "./OverlayImages";
import { handleOptionClick } from "./OptionCard";

const VanList = (props) => {
  const [selectedVanImage, setSelectedVanImage] = useState("");
  const [steps, setSteps] = useState([]);

  //console.log("thiseww " + handleOptionClick);
  const vanSteps = async (props) => {
    const result = await getSteps(props);
    setSteps(result?.vanTypes[0].stepCategories);
  };
  function imageHandler(e) {
    const vanImage = e.target.getAttribute("data-image");
    setSelectedVanImage(vanImage);
  }
  return (
    <>
      <div className="flex top-50 relative">
        {props.vansList.map((item) => (
          <button
            onClick={(e) => {
              vanSteps(e.target.getAttribute("data-id"));
              imageHandler(e);
            }}
            data-id={item.id}
            data-image={item.image?.url || ""}
            className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 border border-blue-700 rounded"
            key={item.id}
          >
            {item.name}
          </button>
        ))}
      </div>
      <Steps steps={steps} />
      {console.log("handleOption " + handleOptionClick)}
      <OverlayImages vanimage={selectedVanImage} />
      <OverlayImages vanimage={handleOptionClick} />
    </>
  );
};
export default VanList;
