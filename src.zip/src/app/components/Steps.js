import { useState } from "react";
import { getOptions } from "../../../graphql";
import Box from "@mui/material/Box";
import Stepper from "@mui/material/Stepper";
import Step from "@mui/material/Step";
import StepLabel from "@mui/material/StepLabel";
import OptionCard from "./OptionCard";

const Steps = (props) => {
  const [options, setOptions] = useState([]);

  const vanOptions = async (props) => {
    const result = await getOptions(props);
    setOptions(result?.options);
  };

  return (
    <>
      <Box className="top-50 bottom-steps" sx={{ width: "100%" }}>
        <Stepper activeStep={1} alternativeLabel>
          {props.steps.map((item) => (
            <Step
              onClick={(e) => {
                vanOptions(e.target.getAttribute("data-id"));
              }}
              data-id={item.id}
              key={item.id}
            >
              <StepLabel>{item.name}</StepLabel>
            </Step>
          ))}
        </Stepper>
      </Box>
      <div className="flex top-50 relative">
        {props.steps.map((item) => (
          <button
            onClick={(e) => {
              vanOptions(e.target.getAttribute("data-id"));
            }}
            data-id={item.id}
            className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 border border-blue-700 rounded"
            key={item.id}
          >
            {item.name}
          </button>
        ))}
      </div>
      <OptionCard options={options} />
    </>
  );
};

export default Steps;
